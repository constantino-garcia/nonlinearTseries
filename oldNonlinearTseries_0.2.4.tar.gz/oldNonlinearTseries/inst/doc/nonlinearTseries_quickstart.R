## ----options,echo=FALSE--------------------------------------------------
# colorblind friendly palette
palette(c("#000000", "#E69F00", "#56B4E9", "#009E73",
          "#F0E442", "#0072B2", "#D55E00", "#CC79A7"))
library('knitr')
knitr::opts_chunk$set(fig.width=7,fig.height=4.7,fig.show='hold')

